total_orders = document.querySelector('#total_orders')
pending_elt = document.querySelector('#pending')
cancelled_elt = document.querySelector('#cancelled')
paid_elt = document.querySelector('#paid')
total_amt_elt = document.querySelector('#total_amt')

function loadOrders(status = 'all') {
    file = '../data/orders.json'
    fetch(file)
        .then(data => data.json())
        .then(res => {
            let paid = 0;
            let pending = 0
            let cancelled = 0
            total_rev = 0;
            // document.write(res);

            total_orders.innerHTML = res.length

            text = ''
            res.forEach(o => {
                if (status == 'all' ) {
                    if (o.status.toLowerCase() == 'completed') paid += 1;
                    if (o.status.toLowerCase() == 'cancelled') cancelled += 1;
                    if (o.status.toLowerCase() == 'pending') pending += 1;
                    total_rev += o.amount
                    text += `<tr>
                            <td>${o.order_id}</td>
                            <td>${o.customer}</td>
                            <td>${o.date}</td>
                            <td>${o.amount}</td>
                            <td>${o.amount}</td>
                            <td><span class="badge paid"> ${o.status} </span></td>
                            <td>
                                <div class="row-actions">
                                    <button class="light" type="button">View</button>
                                    <button class="danger" type="button">Delete</button>
                                </div>
                            </td>
                        </tr>

`
                }
            });
            document.querySelector('#orders')
                .innerHTML = text
            pending_elt.innerHTML = pending
            cancelled_elt.innerHTML = cancelled
            paid_elt.innerHTML = paid
            total_amt_elt.innerHTML = "N" + total_rev
        })
        .catch(e => {
            document.write(e);

        })

}
loadOrders()